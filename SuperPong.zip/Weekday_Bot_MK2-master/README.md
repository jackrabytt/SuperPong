# Weekday_Bot_MK2
literally the worst bot

Responds to each day of the week with a different phrase

not worth your time
